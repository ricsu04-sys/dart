class Criterio {
  int id;
  String descripcion;
  String estado;
  String observacion;

  Criterio({
    required this.id,
    required this.descripcion,
    this.estado = "en revision",
    this.observacion = "",
  });

  void cambiarEstado(String nuevoEstado) {
    estado = nuevoEstado;
  }

  void registrarObservacion(String texto) {
    observacion = texto;
  }

  bool cumple() {
    return estado == "cumple";
  }

  void mostrarInfo() {
    print("Criterio $id: $descripcion");
    print("  Estado: $estado");
    print("  Observación: ${observacion.isEmpty ? 'Sin observaciones' : observacion}");
  }
}