import 'criterio.dart';
import 'modelo_analisis.dart';
import 'verificacion.dart';

void main() {
  var modelo = ModeloAnalisis(
    id: 1,
    nombre: "Modelo de casos de uso",
    descripcion: "Verificación del modelo de casos de uso",
  );

  var c1 = Criterio(id: 1, descripcion: "El caso de uso tiene actor definido");
  var c2 = Criterio(id: 2, descripcion: "El caso de uso tiene flujo alterno");
  var c3 = Criterio(id: 3, descripcion: "El caso de uso tiene precondiciones");

  c1.cambiarEstado("cumple");
  c2.cambiarEstado("no cumple");
  c2.registrarObservacion("Falta describir el flujo alterno con más detalle");
  c3.cambiarEstado("en revision");

  modelo.agregarCriterio(c1);
  modelo.agregarCriterio(c2);
  modelo.agregarCriterio(c3);

  modelo.mostrarCriterios();

  print("Total de criterios: ${modelo.contarCriterios()}");

  var encontrado = modelo.buscarCriterio(2);
  if (encontrado != null) {
    print("Criterio encontrado: ${encontrado.descripcion}");
  } else {
    print("Criterio no encontrado");
  }

  print("");
  var resultado = modelo.verificarCriterios();
  print("Cumplen: ${resultado['cumplen']}");
  print("No cumplen: ${resultado['no cumplen']}");
  print("En revisión: ${resultado['en revision']}");
  print("Porcentaje de cumplimiento: ${modelo.calcularPorcentajeCumplimiento().toStringAsFixed(2)} %");
  print("Estado del modelo: ${modelo.determinarEstado()}");

  print("");
  var verificacion = Verificacion(
    modelo: modelo,
    fecha: "15/09/2026",
    responsable: "Juan Pérez",
    observaciones: "Se recomienda revisar el flujo alterno antes de aprobar.",
  );

  verificacion.generarResumen();
}