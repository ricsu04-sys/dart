import 'criterio.dart';

class ModeloAnalisis {
  int id;
  String nombre;
  String descripcion;
  List<Criterio> criterios;

  ModeloAnalisis({
    required this.id,
    required this.nombre,
    required this.descripcion,
    List<Criterio>? criterios,
  }) : criterios = criterios ?? [];

  void agregarCriterio(Criterio criterio) {
    criterios.add(criterio);
  }

  List<Criterio> consultarCriterios() {
    return criterios;
  }

  void mostrarCriterios() {
    print("Criterios del modelo '$nombre':");
    for (var c in criterios) {
      c.mostrarInfo();
    }
  }

  Criterio? buscarCriterio(int id) {
    for (var c in criterios) {
      if (c.id == id) {
        return c;
      }
    }
    return null;
  }

  int contarCriterios() {
    return criterios.length;
  }

  Map<String, int> verificarCriterios() {
    int cumplen = 0;
    int noCumplen = 0;
    int enRevision = 0;

    for (var c in criterios) {
      if (c.estado == "cumple") {
        cumplen++;
      } else if (c.estado == "no cumple") {
        noCumplen++;
      } else if (c.estado == "en revision") {
        enRevision++;
      }
    }

    return {
      "cumplen": cumplen,
      "no cumplen": noCumplen,
      "en revision": enRevision,
    };
  }

  double calcularPorcentajeCumplimiento() {
    if (criterios.isEmpty) return 0;
    int cumplen = verificarCriterios()["cumplen"]!;
    return (cumplen / criterios.length) * 100;
  }

  String determinarEstado() {
    var resultado = verificarCriterios();
    int noCumplen = resultado["no cumplen"]!;
    int enRevision = resultado["en revision"]!;

    if (noCumplen > 0) {
      return "Requiere ajustes";
    } else if (enRevision > 0) {
      return "En revision";
    } else {
      return "Aprobado";
    }
  }
}