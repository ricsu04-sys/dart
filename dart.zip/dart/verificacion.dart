import 'modelo_analisis.dart';

class Verificacion {
  ModeloAnalisis modelo;
  String fecha;
  String responsable;
  double porcentaje;
  String estadoFinal;
  String observaciones;

  Verificacion({
    required this.modelo,
    required this.fecha,
    required this.responsable,
    this.observaciones = "",
  })  : porcentaje = modelo.calcularPorcentajeCumplimiento(),
        estadoFinal = modelo.determinarEstado();

  void generarResumen() {
    var resultado = modelo.verificarCriterios();

    print("RESULTADO DE LA VERIFICACIÓN");
    print("");
    print("Modelo: ${modelo.nombre}");
    print("Responsable: $responsable");
    print("Fecha: $fecha");
    print("");
    print("Total de criterios: ${modelo.contarCriterios()}");
    print("Cumplen: ${resultado['cumplen']}");
    print("No cumplen: ${resultado['no cumplen']}");
    print("En revisión: ${resultado['en revision']}");
    print("");
    print("Cumplimiento: ${porcentaje.toStringAsFixed(2)} %");
    print("");
    print("Estado: ${estadoFinal.toUpperCase()}");
    if (observaciones.isNotEmpty) {
      print("Observaciones generales: $observaciones");
    }
  }
}